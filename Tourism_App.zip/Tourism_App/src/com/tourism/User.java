package com.tourism;
public class User {
    String name;
    String email;
    String mobile;
    String password;

    public User(String name, String email, String mobile, String password) {
        this.name = name;
        this.email = email;
        this.mobile = mobile;
        this.password = password;
    }
}