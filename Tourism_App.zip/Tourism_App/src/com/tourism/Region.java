package com.tourism;
import java.util.Scanner;

public class Region {
	 public void chooseRegion(User currentUser, int transportChoice) {
	        Scanner scanner = new Scanner(System.in);

	        System.out.println("Select a region in India:");
	        System.out.println("1. karnataka");
	        System.out.println("2. andra pradesh");
	        System.out.println("3. kerala");
	        System.out.println("4. tamil nadu");
	        System.out.println("4. telangana");
	        System.out.print("Enter your choice: ");
	        int regionChoice = scanner.nextInt();

	        calculatePackageAmount(transportChoice, regionChoice);
	    }

	    double calculatePackageAmount(int transportChoice, int regionChoice) {
	        double baseAmount = 0.0;
	        double transportMultiplier = 1.0;
	        double regionMultiplier = 1.0;

	        switch (transportChoice) {
	            case 1:
	                baseAmount = 100.0;
	                break;
	            case 2:
	                baseAmount = 300.0;
	                break;
	            case 3:
	                baseAmount = 200.0;
	                break;
	            default:
	                System.out.println("Invalid transport choice.");
	                return baseAmount;
	        }

	        switch (regionChoice) {
	            case 1:
	                regionMultiplier = 1.2;
	                break;
	            case 2:
	                regionMultiplier = 1.5;
	                break;
	            case 3:
	                regionMultiplier = 1.3;
	                break;
	            case 4:
	                regionMultiplier = 1.4;
	                break;
	            default:
	                System.out.println("Invalid region choice.");
	                return regionMultiplier;
	        }

	        double packageAmount = baseAmount * transportMultiplier * regionMultiplier;
	        System.out.println("Package Amount: " + packageAmount);
			return packageAmount;
	    }
	}



