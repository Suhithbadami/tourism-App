package com.tourism;

public class Booking {
    private String name;
    private String destination;
    private String date;
    private double amount;

    public Booking(String name, String destination, String date, double amount) {
        this.name = name;
        this.destination = destination;
        this.date = date;
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public String getDestination() {
        return destination;
    }

    public String getDate() {
        return date;
    }

    public double getAmount() {
        return amount;
    }
}
